# My Python Web App

Vector search playground with Mercadona products catalog and VoyageAI vs OpenAI comparision

## Setup Instructions

1. **Rename `.env.sample` to `.env` and add the values needed.**
2. **Install Dependencies**:
   - Open a terminal and navigate to the `/backend` directory.
   - Create a virtual environment (optional but recommended):
     - `python -m venv venv`
     - Activate it:
       - On macOS/Linux: `source venv/bin/activate`
   - Run the command:
     ```
     pip install -r requirements.txt
     ```

3. **Run the Application**:
   - In the terminal run:
     ```
     python app.py
     ```
   - Open a web browser and go to `http://127.0.0.1:8080/` to see the webpage with the input text.